import java.util.HashMap;
import java.util.Scanner;

public class SistemaEstudiantes {

    static HashMap<String, Estudiante> estudiantes = new HashMap<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Ingresar estudiante");
            System.out.println("2. Ver todos los estudiantes");
            System.out.println("3. Buscar estudiante por carnet");
            System.out.println("4. Salir");
            System.out.print("Ingrese opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
                switch (opcion) {
                    case 1: ingresarEstudiante(); break;
                    case 2: verEstudiantes(); break;
                    case 3: buscarEstudiante(); break;
                    case 4: System.out.println("Saliendo del sistema..."); break;
                    default: System.out.println("Opción inválida."); break;
                }
            } catch (Exception e) {
                System.out.println("Error: entrada no válida.");
                opcion = 0;
            }
        } while (opcion != 4);
    }

    static void ingresarEstudiante() {
        System.out.print("Carnet: ");
        String carnet = scanner.nextLine();

        if (estudiantes.containsKey(carnet)) {
            System.out.println("⚠️ El carnet ya está registrado.");
            return;
        }

        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Edad: ");
            int edad = Integer.parseInt(scanner.nextLine());
            System.out.print("Carrera: ");
            String carrera = scanner.nextLine();
            System.out.print("Materia: ");
            String materia = scanner.nextLine();

            estudiantes.put(carnet, new Estudiante(nombre, edad, carrera, materia));
            System.out.println("✅ Estudiante agregado con éxito.");
        } catch (Exception e) {
            System.out.println("❌ Error en el ingreso de datos.");
        }
    }

    static void verEstudiantes() {
        if (estudiantes.isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }
        System.out.println("--- LISTADO DE ESTUDIANTES ---");
        for (String carnet : estudiantes.keySet()) {
            System.out.println("Carnet: " + carnet);
            System.out.println(estudiantes.get(carnet));
            System.out.println("-------------------------------");
        }
    }

    static void buscarEstudiante() {
        System.out.print("Ingrese el carnet del estudiante: ");
        String carnet = scanner.nextLine();

        if (estudiantes.containsKey(carnet)) {
            System.out.println("Estudiante encontrado:");
            System.out.println(estudiantes.get(carnet));
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }
}
